<?php

namespace Codilar\ExtendedCatalogImportExport\Model\ResourceModel\Import;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(\Codilar\ExtendedCatalogImportExport\Model\Import::class, \Codilar\ExtendedCatalogImportExport\Model\ResourceModel\Import::class);
    }
}
