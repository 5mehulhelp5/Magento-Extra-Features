<?php

namespace Codilar\ExtendedCatalogImportExport\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Import extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('custom_price_import', 'sku');
    }
}
