<?php
namespace Codilar\ExtendedCatalogImportExport\Model\Import;

use Exception;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\ImportExport\Helper\Data as ImportHelper;
use Magento\ImportExport\Model\Import;
use Magento\ImportExport\Model\Import\Entity\AbstractEntity;
use Magento\ImportExport\Model\Import\ErrorProcessing\ProcessingErrorAggregatorInterface;
use Magento\ImportExport\Model\ResourceModel\Helper;
use Magento\ImportExport\Model\ResourceModel\Import\Data;
use Magento\Framework\MessageQueue\PublisherInterface;

/**
 * Class Courses
 */
class PriceUpdateGrid extends AbstractEntity
{
    const ENTITY_CODE = 'custom_price_import';
    const TABLE = 'custom_price_import';
    const SKU = 'sku';
    const PRICE = 'price';
    const SPECIAL_PRICE = 'special_price';
    const SPECIAL_PRICE_FROM = 'special_price_from_date';
    const SPECIAL_PRICE_TO = 'special_price_to_date';
    const STORE_CODE = 'store_view_code';

    /**
     * If we should check column names
     */
    protected $needColumnCheck = true;

    /**
     * Need to log in import history
     */
    protected $logInHistory = true;

    /**
     * Permanent entity columns.
     */
    protected $_permanentAttributes = [
        'sku'
    ];

    /**
     * Valid column names
     */
    protected $validColumnNames = [
        'sku',
        'price',
        'special_price',
        'special_price_from_date',
        'special_price_to_date',
        'store_view_code'
    ];

    /**
     * @var AdapterInterface
     */
    protected $connection;

    /**
     * @var ResourceConnection
     */
    private $resource;

    private $publisher;


    /**
     * @param JsonHelper $jsonHelper
     * @param ImportHelper $importExportData
     * @param Data $importData
     * @param ResourceConnection $resource
     * @param Helper $resourceHelper
     * @param ProcessingErrorAggregatorInterface $errorAggregator
     * @param PublisherInterface $publisher
     */
    public function __construct(
        JsonHelper $jsonHelper,
        ImportHelper $importExportData,
        Data $importData,
        ResourceConnection $resource,
        Helper $resourceHelper,
        ProcessingErrorAggregatorInterface $errorAggregator,
        PublisherInterface $publisher
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->publisher = $publisher;
        $this->_importExportData = $importExportData;
        $this->_resourceHelper = $resourceHelper;
        $this->_dataSourceModel = $importData;
        $this->resource = $resource;
        $this->connection = $resource->getConnection(ResourceConnection::DEFAULT_CONNECTION);
        $this->errorAggregator = $errorAggregator;
    }

    /**
     * Entity type code getter.
     *
     * @return string
     */
    public function getEntityTypeCode()
    {
        return static::ENTITY_CODE;
    }

    /**
     * Get available columns
     *
     * @return array
     */
    public function getValidColumnNames(): array
    {
        return $this->validColumnNames;
    }

    /**
     * Row validation
     *
     * @param array $rowData
     * @param int $rowNum
     *
     * @return bool
     */
    public function validateRow(array $rowData, $rowNum): bool
    {
        if (isset($this->_validatedRows[$rowNum])) {
            return !$this->getErrorAggregator()->isRowInvalid($rowNum);
        }

        $this->_validatedRows[$rowNum] = true;

        // Example validation: Check if 'sku' and 'price' are not empty
        if (empty($rowData['sku'])) {
            $this->addRowError('SkuIsRequired', $rowNum);
        }
        if (empty($rowData['price'])) {
            $this->addRowError('PriceIsRequired', $rowNum);
        }
        if (empty($rowData['special_price'])) {
            $this->addRowError('SpecialPriceIsRequired', $rowNum);
        }
        if (empty($rowData['special_price_from_date'])) {
            $this->addRowError('FromIsRequired', $rowNum);
        }
        if (empty($rowData['special_price_to_date'])) {
            $this->addRowError('ToIsRequired', $rowNum);
        }
        if (empty($rowData['store_view_code'])) {
            $this->addRowError('StoreCodeIsRequired', $rowNum);
        }

        return !$this->getErrorAggregator()->isRowInvalid($rowNum);
    }

    /**
     * Import data
     *
     * @return bool
     *
     * @throws Exception
     */
    protected function _importData(): bool
    {
        switch ($this->getBehavior()) {
            case Import::BEHAVIOR_DELETE:
                $this->deleteEntity();
                break;
            case Import::BEHAVIOR_REPLACE:
                $this->saveAndReplaceEntity();
                break;
            case Import::BEHAVIOR_APPEND:
                $this->saveAndReplaceEntity();
                break;
        }

        return true;
    }

    /**
     * Save and replace entities
     *
     * @return void
     */
    private function saveAndReplaceEntity()
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/test1.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info('hii');
        $behavior = $this->getBehavior();
        $entityData = [];
        while ($bunch = $this->_dataSourceModel->getNextBunch()) {
            foreach ($bunch as $rowNum => $rowData) {
                if (!$this->validateRow($rowData, $rowNum)) {
                    continue;
                }

                if ($this->getErrorAggregator()->hasToBeTerminated()) {
                    $this->getErrorAggregator()->addRowToSkip($rowNum);
                    continue;
                }

                $sku = $rowData['sku'];
                $entityData[$sku] = [
                    'sku' => $sku,
                    'price' => $rowData['price'],
                    'special_price' => $rowData['special_price'],
                    'special_from_date' => $rowData['special_price_from_date'],
                    'special_to_date' => $rowData['special_price_to_date'],
                    'store_view_code' => $rowData['store_view_code'],
                ];
                $logger->info(json_encode($entityData));

            }
        }

        if ($entityData) {
            $this->publisher->publish('custom_price_import', json_encode($entityData));
            $logger->info(json_encode($entityData));

        }
    }
}
