<?php
namespace Codilar\ExtendedCatalogImportExport\Model\Import;

use Magento\CatalogImportExport\Model\Import\Product\StoreResolver;
use Magento\Framework\Exception\LocalizedException;
use Magento\Catalog\Api\ProductRepositoryInterface;
class PriceUpdateHandler
{
    /**
     * @param ProductRepositoryInterface $productRepository
     * @param StoreResolver $storeResolver
     */
    public function __construct(
        private ProductRepositoryInterface $productRepository,
        private StoreResolver              $storeResolver
    )
    {
    }

    public function process($data)
    {
        try {
            $entityData = json_decode($data, true);
            if ($entityData) {
                foreach ($entityData as $item) {
                    $sku = $item['sku'];
                    $storeCode = $item['store_view_code'] ?? null;
                    if ($storeCode === null) {
                        continue;
                    }
                    $storeId = $this->storeResolver->getStoreCodeToId($storeCode);
                    if (!$storeId) {
                        continue;
                    }
                    $product = $this->productRepository->get($sku, true, $storeId);
                    if ($product) {
                        $product->setPrice($item['price']);
                        $product->setSpecialPrice($item['special_price']);
                        $product->setSpecialFromDate($item['special_from_date']);
                        $product->setSpecialToDate($item['special_to_date']);
                        $product->setStoreId($storeId);
                        $this->productRepository->save($product);
                    } else {
                    }
                }
            }
        } catch (LocalizedException $e) {
            $logger->critical($e->getMessage());
        } catch (\Exception $e) {
            $logger->critical($e->getMessage());
        }
    }
}
