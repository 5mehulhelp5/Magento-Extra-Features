<?php

namespace Codilar\ExtendedCatalogImportExport\Model;

use Magento\Framework\Model\AbstractModel;

class Import extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Codilar\ExtendedCatalogImportExport\Model\ResourceModel\Import::class);
    }
}
