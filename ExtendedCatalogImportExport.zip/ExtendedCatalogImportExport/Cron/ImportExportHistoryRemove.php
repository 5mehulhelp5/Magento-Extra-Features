<?php

namespace Codilar\ExtendedCatalogImportExport\Cron;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Filesystem\Driver\File as DriverInterface;
use Codilar\ExtendedCatalogImportExport\Logger\Logger;

class ImportExportHistoryRemove
{
    const XML_PATH_FOR_IMPORTEXPORT_REMOVE_ENABLE = 'codilar_importexporthistory/general_config/active';
    const XML_PATH_FOR_IMPORTEXPORT_DELETE_LOG_AFTER = 'codilar_importexporthistory/general_config/delete_log_after';

    /**
     * @var ResourceConnection
     */
    private $resource;

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var  DirectoryList
     */
    private $directoryList;

    /**
     * @var  DriverInterface
     */
    private $driverInterface;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param DirectoryList $directoryList
     * @param DriverInterface $driverInterface
     * @param ResourceConnection $resourceConnection
     * @param Logger $logger
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        DirectoryList        $directoryList,
        DriverInterface      $driverInterface,
        ResourceConnection   $resourceConnection,
        Logger               $logger
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->directoryList = $directoryList;
        $this->driverInterface = $driverInterface;
        $this->logger = $logger;
        $this->resource = $resourceConnection;
    }

    /**
     * Cronjob Description
     * Delete import export files from the var folder based on configuration
     */
    public function execute()
    {
        $enabled = $this->scopeConfig->getValue(
            self::XML_PATH_FOR_IMPORTEXPORT_REMOVE_ENABLE,
            ScopeInterface::SCOPE_STORE
        );
        $fileDaysToDeleteAbove = (int)$this->scopeConfig->getValue(
            self::XML_PATH_FOR_IMPORTEXPORT_DELETE_LOG_AFTER,
            ScopeInterface::SCOPE_STORE
        );

        if ($enabled) {
            $this->logger->info("Start of Import Export Log file Remove Cron ");
            try {
                $this->logger->info("Import History Remove Cron started");
                $historyRecords = $this->getImportHistory($fileDaysToDeleteAbove);

                /*
                 * Start of Import delete
                 */
                foreach ($historyRecords as $historyRecord) {
                    $path = $this->directoryList->getPath('var') . '/import_history';
                    $flags = \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::UNIX_PATHS;
                    $iterator = new \FilesystemIterator($path, $flags);
                    /** @var \FilesystemIterator $file */

                    foreach ($iterator as $file) {
                        if ((strpos($file->getFilename(), $historyRecord['imported_file']) !== false)) {
                            $this->driverInterface->deleteFile($file->getPathname());
                            $this->logger->info("Log file Remover Cron:: file deleted" . $file->getPathname());
                        }
                    }
                }
                $this->deleteImportExportHistory($fileDaysToDeleteAbove);

                /*
                 * Start of Export delete
                 */

                $path = $this->directoryList->getPath('var') . '/export';

                if ($this->driverInterface->isExists($path)) {
                    $this->logger->info("Export History Remove Cron started");
                    $flags = \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::UNIX_PATHS;

                    $iterator = new \FilesystemIterator($path, $flags);

                    foreach ($iterator as $file) {
                        $fileModifiedDate = date('m/d/Y h:m:s', $file->getMTime());
                        $deleteFilesBeforeDate = date('m/d/Y h:m:s', strtotime('-' . $fileDaysToDeleteAbove . ' days'));

                        if ($fileModifiedDate < $deleteFilesBeforeDate) {
                            $this->driverInterface->deleteFile($file->getPathname());
                            $this->logger->info(
                                "Log file Export History Removed Cron: file deleted-" . $file->getPathname()
                            );
                        }
                    }
                }
                $this->logger->info("End of Import Export Log file Remove Cron ");
            } catch (\Exception $e) {
                $this->logger->error("Import Export History Remove Cron Error" . $e->getMessage());
            }
        }
    }

    /**
     * @param $beforeDays
     * @return array
     */
    public function getImportHistory($beforeDays)
    {
        $select = "SELECT * FROM `import_history` where started_at < NOW() - INTERVAL {$beforeDays} DAY";
        return $this->resource->getConnection()->fetchAll($select);
    }

    /**
     * @param $beforeDays
     * @return \Zend_Db_Statement_Interface
     */
    public function deleteImportExportHistory($beforeDays)
    {
        $select = "DELETE FROM `import_history` WHERE started_at < NOW() - INTERVAL {$beforeDays} DAY";
        return $this->resource->getConnection()->query($select);
    }
}
