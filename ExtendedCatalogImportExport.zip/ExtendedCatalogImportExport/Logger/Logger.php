<?php
namespace Codilar\ExtendedCatalogImportExport\Logger;

class Logger extends \Monolog\Logger
{
}
