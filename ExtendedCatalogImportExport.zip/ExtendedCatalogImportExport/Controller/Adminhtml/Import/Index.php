<?php

namespace Codilar\ExtendedCatalogImportExport\Controller\Adminhtml\Import;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{
    protected $resultPageFactory;

    public function __construct(Context $context, PageFactory $resultPageFactory)
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Codilar_ExtendedCatalogImportExport::codilar_importexport_history');
        $resultPage->getConfig()->getTitle()->prepend(__('Import Grid'));

        return $resultPage;
    }
}
