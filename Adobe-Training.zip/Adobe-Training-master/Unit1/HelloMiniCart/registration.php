<?php
// Exercise: 1.3.2.1
/**
 * Copyright © Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Unit1_HelloMiniCart',
    __DIR__
);
