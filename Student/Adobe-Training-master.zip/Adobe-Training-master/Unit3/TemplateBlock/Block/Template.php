<?php
/**
 *
 * Copyright © Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Unit3\TemplateBlock\Block;

/**
 * Class Template
 * Template extends \Magento\Framework\View\Element\Template
 */
class Template extends \Magento\Framework\View\Element\Template
{

}
